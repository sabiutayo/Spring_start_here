package repositories;

import org.springframework.stereotype.Repository;

@Repository
public class CommentRepository {
}
