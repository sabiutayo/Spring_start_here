package com.example.exceptions;

public class AccountNotFoundException extends RuntimeException {
}
